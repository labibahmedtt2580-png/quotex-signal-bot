const $ = (id) => document.getElementById(id);

function parseCandles(raw) {
  const lines = raw.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const candles = [];
  for (let i = 0; i < lines.length; i++) {
    const cols = lines[i].split(/[,\s;]+/).map(Number);
    if (cols.length < 4 || cols.slice(0,4).some(n => !Number.isFinite(n))) {
      throw new Error(`লাইন ${i+1}: open,high,low,close চারটি সংখ্যা দিন।`);
    }
    const [open, high, low, close] = cols;
    if (high < Math.max(open, close, low) || low > Math.min(open, close, high)) {
      throw new Error(`লাইন ${i+1}: OHLC মান সঠিক নয়।`);
    }
    candles.push({open, high, low, close});
  }
  if (candles.length < 30) throw new Error("কমপক্ষে 30টি বৈধ ক্যান্ডেল দিন।");
  return candles;
}

function ema(values, period) {
  const k = 2 / (period + 1);
  let current = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  for (let i = period; i < values.length; i++) current = values[i] * k + current * (1-k);
  return current;
}

function rsi(values, period=14) {
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const d = values[i] - values[i-1];
    if (d > 0) gains += d; else losses -= d;
  }
  let avgGain = gains / period, avgLoss = losses / period;
  for (let i = period + 1; i < values.length; i++) {
    const d = values[i] - values[i-1];
    avgGain = (avgGain * (period - 1) + Math.max(d,0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-d,0)) / period;
  }
  if (avgLoss === 0) return 100;
  return 100 - (100 / (1 + avgGain / avgLoss));
}

function macdHistogram(values) {
  // Compute EMA series for MACD(12,26,9), not just the last raw difference.
  function seriesEma(arr, period) {
    const k = 2 / (period + 1);
    const out = [];
    let prev = arr[0];
    out.push(prev);
    for (let i=1;i<arr.length;i++) { prev = arr[i]*k + prev*(1-k); out.push(prev); }
    return out;
  }
  const e12 = seriesEma(values, 12), e26 = seriesEma(values, 26);
  const macd = values.map((_,i)=>e12[i]-e26[i]);
  const signal = seriesEma(macd, 9);
  return macd[macd.length-1] - signal[signal.length-1];
}

function analyze(candles) {
  const closes = candles.map(c=>c.close);
  const e9 = ema(closes.slice(-Math.max(9, Math.min(closes.length, 80))), 9);
  const e21 = ema(closes.slice(-Math.max(21, Math.min(closes.length, 80))), 21);
  const r = rsi(closes, 14);
  const m = macdHistogram(closes);
  const bullish = e9 > e21 && r >= 52 && r <= 70 && m > 0;
  const bearish = e9 < e21 && r <= 48 && r >= 30 && m < 0;
  let signal = "WAIT", reason = "ইন্ডিকেটরগুলো একই দিকে একমত নয়; অপেক্ষা করুন।", cls = "wait";
  if (bullish) { signal = "CALL 🔼"; reason = "EMA 9 > EMA 21, RSI মোমেন্টাম ঊর্ধ্বমুখী এবং MACD histogram ধনাত্মক।"; cls = "call"; }
  if (bearish) { signal = "PUT 🔽"; reason = "EMA 9 < EMA 21, RSI মোমেন্টাম নিম্নমুখী এবং MACD histogram ঋণাত্মক।"; cls = "put"; }
  return {signal, reason, cls, r, e9, e21, m};
}

function showResult(result) {
  $("signal").textContent = result.signal;
  $("signal").className = "signal " + result.cls;
  $("reason").textContent = result.reason;
  $("rsi").textContent = result.r.toFixed(2);
  $("ema9").textContent = result.e9.toFixed(5);
  $("ema21").textContent = result.e21.toFixed(5);
  $("macd").textContent = result.m.toFixed(6);
  $("message").textContent = `বিশ্লেষণ সম্পন্ন · ${$("market").value} · ${$("timeframe").value}m · ইনপুট ক্যান্ডেল: ${$("candles").value.trim().split(/\r?\n/).filter(Boolean).length}টি। এটি অনুমোদিত লাইভ ফিড থেকে আসেনি।`;
  $("message").className = "message";
}

$("analyzeBtn").addEventListener("click", () => {
  try { showResult(analyze(parseCandles($("candles").value))); }
  catch (e) { $("message").textContent = e.message; $("message").className = "message error"; }
});

$("sampleBtn").addEventListener("click", () => {
  // Deterministic synthetic sample only. It is not real or live market data.
  let close = 1.1;
  const lines = [];
  for (let i=0;i<50;i++) {
    const open = close;
    const drift = i < 25 ? 0.00004 : -0.000025;
    close = open + drift + Math.sin(i*1.7)*0.00008;
    const high = Math.max(open,close) + 0.00012;
    const low = Math.min(open,close) - 0.00012;
    lines.push([open,high,low,close].map(n=>n.toFixed(5)).join(","));
  }
  $("candles").value = lines.join("\n");
  $("message").textContent = "নমুনা ডেটা লোড হয়েছে—এটি কৃত্রিম ডেটা, লাইভ মার্কেট নয়।";
  $("message").className = "message";
  try { showResult(analyze(parseCandles($("candles").value))); }
  catch (e) { $("message").textContent = e.message; }
});
